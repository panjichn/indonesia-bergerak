         <footer>
			<div class="footer-wrapper">
				<div class="container">
					<div class="row">
						<div id="bottom1" class="col-sm-6 col-md-3">
							<p class="footer-logo"><img src="img/bottom-logo1.png" alt="logo" style="max-width: 170px;"></p>
							<p class="footer-info">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et aliqua.</p>
							<!--<div class="footer-contact">
								<p>
									<span>Email:</span>
									info@yourcompnay.com
								</p>
								<p>
									<span>Fax:</span>
									+0123 4567 8910
								</p>
							</div>-->
						</div> <!-- //bottom1 -->
	
						<div id="bottom2" class="col-sm-6 col-md-3">
							<div class="bottom-menu">
								<h3 class="title">Quick Link</h3>
								<div class="pull-left">
									<ul class="menu">
										<li><a href="#">Home</a></li>
										<li><a href="about.html">Kementrian &amp; Lembaga Negara</a></li>
										<li><a href="advertisement.html">Kabar BUMN</a></li>
										<li><a href="article-categories.html">Kabar Daerah</a></li>
										<li><a href="#">Kementrian</a></li>
									</ul>
								</div>
								<!--<div class="pull-right">
									<ul class="menu">
										<li><a href="contact.html">Regional</a></li>
										<li><a href="#">Yayasan</a></li>
										
									</ul>
								</div>-->
							</div>
						</div> <!-- //bottom2 -->
	
						<div id="bottom3" class="col-sm-6 col-md-3">
							<div class="">
								<h3 class="title">News Tag</h3>
								<div class="tags">
									<a class="tag-name" href="#">World</a>
									<a class="tag-name" href="#">Sports</a>
									<a class="tag-name" href="#">Politics</a>
									<a class="tag-name" href="#">Media</a>
									<a class="tag-name" href="#">Logic</a>
									<a class="tag-name" href="#">Fashion</a>
									<a class="tag-name" href="#">Culture</a>
									<a class="tag-name" href="#">Business</a>
									<a class="tag-name" href="#">Art</a>
								</div>
							</div>
						</div> <!-- //bottom3 -->
	
						<div id="bottom4" class="col-sm-6 col-md-3">
							<div class="social-wrapper">
								<h3 class="title">Social Link</h3>
								<ul class="social-icons">
									<li><a target="_blank" href="#"><i class="fa fa-facebook"></i> Facebook</a></li>
									<li><a target="_blank" href="#"><i class="fa fa-twitter"></i> Twitter</a></li>
									
								</ul>
							</div>
						</div> <!-- //bottom4 -->
					</div> <!-- //row -->
				</div>  <!-- //container -->
			</div> <!-- //footer-wrapper --> 
	
			<div class="copyright-wrapper">
				<div class="container">
					<div class="row">
						<div class="col-sm-6 col-md-6">
							<p class="copyright"> Copyright © 2017 <a href="http://joomshaper.com">Detikcom</a> All rights reserved.</p>
						</div>
						<div class="col-sm-6 col-md-6">
							<p class="pull-right">Design &amp; Devleopment by&nbsp;<a href="http://www.joomshaper.com/">Detikcom</a></p>
						</div>
					</div>  <!-- //row -->
				</div> <!-- //container -->
			</div> <!-- //copyright-wrapper -->
		</footer>