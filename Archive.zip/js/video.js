$(document).ready(function () {

    $(".player").mb_YTPlayer();

});