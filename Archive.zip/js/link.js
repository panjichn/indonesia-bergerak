document.getElementById("link-pertamina").onclick = function() {
    window.open("http://microsite.detik.com/display/ib-pertamina/");
}
document.getElementById("link-pln").onclick = function() {
    window.open("http://microsite.detik.com/display/ib-pln/");
}